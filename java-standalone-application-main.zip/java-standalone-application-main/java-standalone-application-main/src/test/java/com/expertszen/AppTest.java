package com.expertszen;

import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.Properties;


import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.sql.DataSource;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.junit.Test;

public class AppTest {
    @Test
    public void testApp() throws EmailException {
        assertTrue(true);
        
        
        /*Email email=new SimpleEmail();
        email.setHostName("smtp.gmail.com");
        email.setSmtpPort(465);
        email.setAuthenticator(new DefaultAuthenticator("patjenkins83@gmail.com","Test1234@"));
        email.setSSLOnConnect(true);
        email.setFrom("pathmanaban326@gmail.com");
        
        email.setSubject("TEst");
        email.setMsg("Test");
        email.addTo("pathmanaban326@gmail.com");
        email.send();*/final String username = "pathutmb@outlook.com";
       
        System.out.println("Hello from Java Standalone Application!");
        
        
}
}
