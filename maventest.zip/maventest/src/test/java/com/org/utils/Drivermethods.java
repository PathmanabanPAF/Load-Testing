package com.org.utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Drivermethods {
	WebDriver driver;
	

	int i=0;
	public Drivermethods(WebDriver driver)
	{
		this.driver=driver;
		
	}
	
	public void launchApp(String url)  {
		try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			driver.get(url);
			//takesnap();
			System.out.println("Browser launched successfully");
			//em.reportstep("Launch URL", "URL launched", "Pass");
		} catch (Exception e) {
			e.printStackTrace();
			// TODO Auto-generated catch block
			System.out.println("Browser launch failed");
			//em.reportstep("Launch URL", "URL not launched", "Failed");
			//takesnap();
		}
	}

}
