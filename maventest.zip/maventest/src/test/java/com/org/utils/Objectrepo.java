package com.org.utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class Objectrepo {
    // Locating elements using @FindBy
    public static By Registerlink=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
    public static By Gender=By.xpath("//*[@id='gender-male']");
    public static By firstName=By.xpath("//*[@id='FirstName']");
    public static By LastName=By.xpath("//*[@id='LastName']");
    public static By Email=By.xpath("//*[@id='Email']");
    public static By passwd=By.xpath("//*[@id='Password']");
    public static By confirmpasswd=By.xpath("//*[@id='ConfirmPassword']");
    public static By registerbtn=By.xpath("//*[@id='register-button']");
    
    public static By loginlink=By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a");
    public static By Loginbtn=By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input");
    
    public static By Electronics=By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[1]/a");
    public static By copmputer=By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[2]/a");
    

    // Constructor to initialize elements
    public Objectrepo(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

  
}
