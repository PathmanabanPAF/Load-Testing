package com.org.maventest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class HelloworldTest {

	@Test
	public void login() throws InterruptedException
	{
System.out.println("TEST");
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\PathTesting\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\Driver\\chromedriver.exe");
		driver=new ChromeDriver();
		
		driver.get("https://www.google.com/");
		
		driver.findElement(By.name("q")).sendKeys("test");
		Thread.sleep(3000);
		//driver.findElement(By.id("lastname")).sendKeys("test");
		//Thread.sleep(3000);
		//driver.findElement(By.id("sex-0")).click();;
		//Thread.sleep(11000);
		driver.close();
	  
	  
	}
}
