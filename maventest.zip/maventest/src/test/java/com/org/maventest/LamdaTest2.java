package com.org.maventest;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class LamdaTest2 {
	public String Username="authenticator83";
	public String accesskey="cQJt049WEUUDfOBENkQQL5D1S5ziycKUbMJuUGmOqhiARI5MCK";
	public static RemoteWebDriver driver= null;
	public String gridURL="@hub.lamdatest.com/wd/hub";
	String URL1=null;
	public static final String URL="https://pathmanabang1:tkzKVN6S7xXp4BdpfSt1"+"@hub-cloud.browserstack.com/wd/hub";
	@Test
	public void Entertest1() throws InterruptedException, MalformedURLException
	{
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\PathTesting\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\Driver\\chromedriver.exe");
System.out.println("TEST");
		
		WebDriver driver;
		
		
		DesiredCapabilities dc=new DesiredCapabilities();
		dc.setCapability("deviceName", "Samsung Galaxy S22 Ultra");
		dc.setCapability("os_version", "12.0");
		dc.setCapability("realMobile", "true");
		dc.setCapability("name", "Pathtest");
		dc.setCapability("Project", "Pathtest");
		dc.setCapability("app", "bs://68b6e668418119a1e8da787369f10f3e0b281537");
		Thread.sleep(000);
		driver=new RemoteWebDriver(new URL(URL),dc);
		Thread.sleep(11000);
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='my_text_fieldCD']")).sendKeys("TEST");
		Thread.sleep(3000);
		driver.close();
	}

	
}
