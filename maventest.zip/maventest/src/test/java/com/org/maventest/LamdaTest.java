package com.org.maventest;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

public class LamdaTest {
	public String Username="authenticator83";
	public String accesskey="cQJt049WEUUDfOBENkQQL5D1S5ziycKUbMJuUGmOqhiARI5MCK";
	public static RemoteWebDriver driver= null;
	public String gridURL="@hub.lamdatest.com/wd/hub";
	String URL1=null;
	
	@Test
	public void Entertest() throws InterruptedException, MalformedURLException
	{
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\PathTesting\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\Driver\\chromedriver.exe");
		DesiredCapabilities capabilities=new DesiredCapabilities();
		
		capabilities.setCapability("browserName", "chrome");
		capabilities.setCapability("version", "121.0");
		capabilities.setCapability("platform", "WINDOWS");
		//capabilities.setCapability("resolution", "1024x768");
		capabilities.setCapability("build", "LambdaTestSampleApp"); // CI/CD job or build name;
		capabilities.setCapability("name", "LambdaTestJavaSample");
		
		capabilities.setCapability("network", true);
		capabilities.setCapability("visual", true);
		capabilities.setCapability("video", true);
		capabilities.setCapability("console", true);
		URL1="";
		driver=new RemoteWebDriver(new URL("https://pathmanabang1:tkzKVN6S7xXp4BdpfSt1@hub.browserstack.com/wd/hub"), capabilities);
		
		Thread.sleep(3000);
		driver.get("Https://google.co.in");
		Thread.sleep(3000);
		driver.findElement(By.name("q")).sendKeys("Testing");
		Thread.sleep(3000);
		driver.quit();
		
	}
	@Test
	public void Entertest1() throws InterruptedException, MalformedURLException
	{
System.out.println("TEST");
		
		WebDriver driver;
		
		
		DesiredCapabilities dc=new DesiredCapabilities();
		dc.setCapability("deviceName", "Samsung Galaxy S22 Ultra");
		dc.setCapability("os_version", "12.0");
		dc.setCapability("realMobile", "true");
		dc.setCapability("name", "Pathtest");
		dc.setCapability("Project", "Pathtest");
		dc.setCapability("app", "bs://2cfd4a3f1de5cd5ed315f65d1e9dcb39c4586104");
		Thread.sleep(3000);
		driver=new RemoteWebDriver(new URL("https://pathmanabang1:tkzKVN6S7xXp4BdpfSt1@hub.browserstack.com/wd/hub"),dc);
		Thread.sleep(3000);
		driver.findElement(By.xpath("test")).click();
		Thread.sleep(3000);
		driver.close();
		
	}

	
}
