package com.org.maventest;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.org.utils.Drivermethods;
import com.org.utils.Objectrepo;

public class Demowebshop {
	 WebDriver driver;
	 String url="https://demowebshop.tricentis.com/";
	@Before()
	public void initatebrowser() throws InterruptedException
	{	
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\PathTesting\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\Driver\\chromedriver.exe");
		//driver=new ChromeDriver();
		//WebDriver driver;
		//Drivermethods  wM = new Drivermethods(driver);
		//wM.launchApp(url);
	}
	
	@After()
	public void closebrowser(WebDriver driver)
	{
		driver.close();
	}
	
	//Test1
	@Test(priority=1, groups={"demoshop"})
	public void Registration() throws InterruptedException
	{
		System.out.println("TEST");
		
		//WebDriver driver;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\PathTesting\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\Driver\\chromedriver.exe");
		driver=new ChromeDriver();

		try{
			
	
		Drivermethods  wM = new Drivermethods(driver);
		wM.launchApp(url);
		//driver.get("https://demowebshop.tricentis.com/");
		//Thread.sleep(5000);
		//Objectrepo  or = new Objectrepo(driver);
		
		//driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
	    driver.findElement(Objectrepo.Registerlink).click();   
		Thread.sleep(5000);
		driver.findElement(Objectrepo.Gender).click();
		Thread.sleep(5000);
		driver.findElement(Objectrepo.Gender).click();
		Thread.sleep(5000);
		driver.findElement(Objectrepo.firstName).sendKeys("Patetst");
		Thread.sleep(5000);
		driver.findElement(Objectrepo.LastName).sendKeys("Patetst");
		Thread.sleep(5000);
		driver.findElement(Objectrepo.Email).sendKeys("Patetst1@gmail.com");
		Thread.sleep(5000);
		driver.findElement(Objectrepo.passwd).sendKeys("test123");
		Thread.sleep(5000);
		driver.findElement(Objectrepo.confirmpasswd).sendKeys("test123");
		Thread.sleep(5000);
		driver.findElement(Objectrepo.registerbtn).click();
		Thread.sleep(5000);
		//driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("test123");
		//Thread.sleep(5000);
		//driver.findElement(By.id("lastname")).sendKeys("test");
		//Thread.sleep(3000);
		//driver.findElement(By.id("sex-0")).click();;
		//Thread.sleep(11000);
		driver.close();
		}catch(Exception e)
		{
			driver.close();
		}
	  
	  
	}
	
	//Test2 with parameterization
	@Test(priority=2, groups={"demoshop"})
	@Parameters({"Patetst@gmail.com","test123"})
	public void Login() throws InterruptedException
	{
System.out.println("TEST");
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\PathTesting\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\Driver\\chromedriver.exe");
		driver=new ChromeDriver();
		
		try{
			String url="https://demowebshop.tricentis.com/";
		
			Drivermethods  wM = new Drivermethods(driver);
			wM.launchApp(url);
		//driver.get("https://demowebshop.tricentis.com/");
		Thread.sleep(5000);
		
		driver.findElement(Objectrepo.loginlink).click();
		Thread.sleep(5000);
		driver.findElement(Objectrepo.Email).sendKeys("Patetst@gmail.com");
		Thread.sleep(5000);
		driver.findElement(Objectrepo.passwd).sendKeys("test123");
		Thread.sleep(5000);
		
		//Thread.sleep(5000);
		driver.findElement(Objectrepo.Loginbtn).click();
		Thread.sleep(5000);
		//driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("test123");
		//Thread.sleep(5000);
		//driver.findElement(By.id("lastname")).sendKeys("test");
		//Thread.sleep(3000);
		//driver.findElement(By.id("sex-0")).click();;
		//Thread.sleep(11000);
		driver.close();
		}catch(Exception e)
		{
			driver.close();
		}
	  
	  
	}
	
	//Test3 - Search Product
	@Test(priority=3, groups={"demoshop"})
	public void Search() throws InterruptedException
	{
System.out.println("TEST");
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\PathTesting\\PEGA\\PAF_QA\\Automation\\PAF\\PAF_Workspace\\Driver\\chromedriver.exe");
		driver=new ChromeDriver();
		
		try{
			
		
		
		driver.get("https://demowebshop.tricentis.com/");
		Thread.sleep(5000);
		
		driver.findElement(Objectrepo.Electronics).click();
		Thread.sleep(5000);
		driver.findElement(Objectrepo.copmputer).click();
		Thread.sleep(5000);
		//driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("test123");
		//Thread.sleep(5000);
		
		//Thread.sleep(5000);
		//driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		//Thread.sleep(5000);
		//driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("test123");
		//Thread.sleep(5000);
		//driver.findElement(By.id("lastname")).sendKeys("test");
		//Thread.sleep(3000);
		//driver.findElement(By.id("sex-0")).click();;
		//Thread.sleep(11000);
		driver.close();
		}catch(Exception e)
		{
			driver.close();
		}
	  
	  
	}
}
